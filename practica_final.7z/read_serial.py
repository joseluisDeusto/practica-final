#Ejemplo para recibir datos 
import serial
import time
from pub import enviar_mensaje_mqtt

uart_baudrate = 115200 #debe ser = que el configurado en el tx, este caso la EK
# LINUX
# Para listar dispositvos conectados en la terminal: $ lsusb
# con cable USB
uart_serial = serial.Serial(
    '/dev/ttyUSB0', 115200, timeout=10,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.SEVENBITS
)
# WINDOWS
# Buscar en device manager el numero del puerto COM
uart_serial = serial.Serial(
    'COM9', 115200, timeout=10,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.SEVENBITS
)

if uart_serial.is_open:
    while True:
        size = uart_serial.inWaiting()
        if size:
            data = uart_serial.read(size)
            # El dato recibido está en formato de bytes
            received_data_string = data.decode('utf-8')
            print (received_data_string)
            enviar_mensaje_mqtt('Deusto-2020-029', received_data_string)
            print ('mensaje enviado al broker mqtt')
        else:
            print ('no data')
        time.sleep(1)
else:
    print ('Puerto serie no abierto')

uart_serial.close() # cerrar
