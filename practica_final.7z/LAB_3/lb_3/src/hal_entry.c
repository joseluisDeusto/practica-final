#include "hal_data.h"
#include "r_adc_api.h"
#include "r_iic_master.h"
#include "display.h"
#include "adc.h"
#include <stdio.h>
#include <stdint.h>
volatile bool pulsador = false;
volatile bool system_on = false;


fsp_err_t icu_init(void);
fsp_err_t icu_enable(void);
void icu_deinit(void);

#define BUZZER_PINBSP_IO_PORT_01_PIN_13
bool buzzerActivated = false;


uint8_t f1[0x02] = {0x00, 0x80};// Comandos para configurar la primera  línea en el LCD
uint8_t f2[0x02] = {0x00, 0xC0};// Comandos para configurar la segunda línea en el LCD
uint8_t fila_arriba[0x09] = {0x40, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80}; // Matrices  lineas 1 en el LCD
uint8_t fila_abajo[0x09] = {0x40, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80};// Matrices  lineas 2 en el LCD



#define tamanoFiltro 5 //Definomos la constante con un valor de 5.

// Declaración de un arreglo 'filtro' que almacenará las últimas 'tamanoFiltro' lecturas.
uint16_t filtro[tamanoFiltro];


uint8_t indiceFiltro = 0;// Se utiliza para saber en qué posición del arreglo se debe insertar la próxima lectura.



void init_led(void) {
    // Inicializar el módulo IOPORT y configurar los pines
    fsp_err_t err = R_IOPORT_Open(&g_ioport_ctrl, &g_bsp_pin_cfg);
        assert(FSP_SUCCESS == err);

        err = R_IOPORT_PinCfg(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_06, IOPORT_CFG_PORT_DIRECTION_OUTPUT); // Configurar el pin del LED como salida
        assert(FSP_SUCCESS == err);

}

void parpadeo_led(void) {
    fsp_err_t err;
    // Encender el LED
     err = R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_06, BSP_IO_LEVEL_HIGH);
     assert(FSP_SUCCESS == err);

     // Delay
     R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);

     // Apagar el LED
     err = R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_06, BSP_IO_LEVEL_LOW);
     assert(FSP_SUCCESS == err);

     // Delay
     R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);
}


// Función Filtro para agregar una nueva lectura al arreglo 'filtro'.
void Filtro(uint16_t nuevaLectura) {
    // Almacena la nueva lectura en la posición actual del índice.
    filtro[indiceFiltro] = nuevaLectura;

    // Incrementa el índice y usa el operador módulo (%) con 'tamanoFiltro'
    // para asegurar que el índice siempre esté dentro del rango [0, tamanoFiltro-1].
    // Esto crea un comportamiento de buffer circular.
    indiceFiltro = (indiceFiltro + 1) % tamanoFiltro;
}

// Función para calcular la media del filtro.
uint16_t calcularMediana() {
    // Array temporal para almacenar y ordenar las lecturas.
    uint16_t valoresOrdenados[tamanoFiltro];

    // Copia los valores del filtro al array temporal.
      memcpy(valoresOrdenados, filtro, sizeof(filtro));  // memcpy es una función de la biblioteca estándar que copia un bloque de memoria.

    // Bucle para ordenar el array 'valoresOrdenados'.
    // Se utiliza un algoritmo de ordenamiento por burbuja.
    for (int i = 0; i < tamanoFiltro - 1; i++) {
        for (int j = i + 1; j < tamanoFiltro; j++) {
            // Si el elemento en la posición j es menor que el elemento en la posición i,
            // intercambia los valores para ordenarlos.
            if (valoresOrdenados[j] < valoresOrdenados[i]) {
                uint16_t temp = valoresOrdenados[i];
                valoresOrdenados[i] = valoresOrdenados[j];
                valoresOrdenados[j] = temp;
            }
        }
    }


    return valoresOrdenados[tamanoFiltro / 2];// Obtenemos el valor medio
}


void init_zumbador(void) {

    // Inicializar el módulo IOPORT y configurar los pines
     fsp_err_t err = R_IOPORT_Open(&g_ioport_ctrl, &g_bsp_pin_cfg);
     assert(FSP_SUCCESS == err);
        // Configurar el pin del LED como salida
     err = R_IOPORT_PinCfg(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_13, IOPORT_CFG_PORT_DIRECTION_OUTPUT);
     assert(FSP_SUCCESS == err);

}


void zumbador(void){
    // Verificar si el zumbador ya ha sido activado
    if (!buzzerActivated) {
        // Activar el zumbador
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_13, BSP_IO_LEVEL_HIGH);

        // Mantener activo por 1 segundo
        R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);

        // Apagar el zumbador
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_13, BSP_IO_LEVEL_LOW);

        // Establecer la bandera para indicar que el zumbador ya ha sido activado
        buzzerActivated = true;
    }
    // Si el zumbador ya ha sido activado, no hacer nada
}




void init_pulsador(void) {
    fsp_err_t err;

    err = R_ICU_ExternalIrqOpen(&g_external_irq0_ctrl, &g_external_irq0_cfg); // pulsador
    assert(FSP_SUCCESS == err);

    err = R_ICU_ExternalIrqCallbackSet(&g_external_irq0_ctrl, Btn_interruption, NULL, NULL);
    assert(FSP_SUCCESS == err);
}

void Btn_interruption(external_irq_callback_args_t *p_args) {

    if (p_args->channel == g_external_irq0_cfg.channel) { //si el canal de la interrupción que activó la función es igual al canal configurado
        system_on = true;  // Activar el sistema
    }
}


// Función  que muestra "SYSTEM ON" en el LCD en la fila de arriba
void mostrarSystemOn() {
    buzzerActivated=0;
    //primera linea
    fila_arriba[0x00] = 0x40;
    fila_arriba[0x01] = 0x53;//s
    fila_arriba[0x02] = 0x59;//y
    fila_arriba[0x03] = 0x53;//s
    fila_arriba[0x04] = 0x54;//t
    fila_arriba[0x05] = 0x45;//e
    fila_arriba[0x06] = 0x4D;//m
    fila_arriba[0x07] = 0x4F;//O
    fila_arriba[0x08] = 0x4E;//n
    //segunda linea
    fila_abajo[0x00] = 0x40;
    for (int i = 0; i <= 8; i++) {
            fila_abajo[i+1] = 0x80; // Rellenar el resto de la primera fila con 0x80 que es vacio
        }

    write_LCD(f1, fila_arriba);  // Escribe "SYSTEMON" en la primera línea del LCD
    write_LCD(f2, fila_abajo); // Deja vacia la segunda linea
}


void DisplayLCD(uint16_t value, uint8_t fila_arriba[]) {
    char str[6]; // Ajustando el tamaño del buffer según el máximo posible para uint16_t.
    // Convertir el valor numérico a una cadena de caracteres
    sprintf(str, "%u", value);

    // Configuración inicial para LCD
    fila_arriba[0] = 0x40;

    // Rellenar la primera fila con los dígitos convertidos a ASCII o con 0x80 si no hay dígito
    for (int i = 0; i < 5; i++) {
        if (i < strlen(str)) {
            fila_arriba[i + 1] = str[i]; // Asignar dígitos convertidos a ASCII
        } else {
            fila_arriba[i + 1] = 0x80; // Rellenar con 0x80 si no hay más dígitos
        }
    }


    for (int i = 6; i <= 8; i++) {
        fila_arriba[i] = 0x80; // Rellenar el resto de la primera fila con 0x80 que es vacio
    }
}

// Función para mostrar una alerta en el LCD
void DisplayLCDAlerta(int nivel, uint8_t array[]) {

    if (nivel == 4) {
        parpadeo_led();
        if (buzzerActivated==0){
        zumbador();
        }
        // Configuración para mostrar "peligro" en el LCD
        fila_abajo[0x00] = 0x40;
        fila_abajo[0x01] = 0x50; // P
        fila_abajo[0x02] = 0x45; // E
        fila_abajo[0x03] = 0x4C; // L
        fila_abajo[0x04] = 0x49; // I
        fila_abajo[0x05] = 0x47; // G
        fila_abajo[0x06] = 0x52; // R
        fila_abajo[0x07] = 0x4F; // O
        fila_abajo[0x08] = 0x80;


    }
}

// Función para determinar el nivel de velocidad
int nivel_velocidad(uint16_t mediana) {

    const uint16_t valor = 10000;

    if (mediana < valor){
        return 3;
    }else {
        return 4; // Nivel de velocidad 4 mayor a 10000
    }
}

// Función de callback del temporizador
void timer_callback(timer_callback_args_t *p_args) {
    if (TIMER_EVENT_CYCLE_END == p_args->event) {
        // Iniciar la conversión ADC y esperar a que finalice
        ADCStartScan();
        ADCWaitConversion();


        uint16_t adc_result = ReadADC(ADC_CHANNEL_4);  // valor de la lectura del ADC

        // Actualizar el filtro y calcular la media
        Filtro(adc_result);
        // Calcular la mediana del filtro
        uint16_t mediana = calcularMediana();
        int nivel = nivel_velocidad(adc_result);
            if (nivel == 4) {
                //  velocidad y  alerta en el segundo LCD
                DisplayLCD(mediana, fila_arriba);


                DisplayLCDAlerta(nivel, fila_abajo);
            } else {

                mostrarSystemOn(); // estado normal

            }
    }
}

// Función de entrada del HAL
void hal_entry(void) {
    fsp_err_t err = FSP_SUCCESS;
    err = R_GPT_Open(&g_timer0_ctrl, &g_timer0_cfg);
    assert(FSP_SUCCESS == err);
    (void) R_GPT_Start(&g_timer0_ctrl);

    // Inicializar el ADC, I2C y LCD
    ADCInit();
    fsp_err_t i2c = init_i2c();
    clear_i2c();

    initialice_LCD();
    /* TODO: add your own code here */





    /* 1. Inicializar el driver IRQ*/
    err = icu_init();
    if (FSP_SUCCESS != err)
    {
        // Manejar error de inicialización

        printf("Error en la inicializacion del driver");
    }


    // Habilitar el IRQ driver
    err = icu_enable();
    if (FSP_SUCCESS != err)
    {
        // Si habilitar falla, desinicializar el controlador de IRQ para no dejar recursos colgados.
        icu_deinit();
        // Manejar el error
        while(1); // Loop infinito
    }

    init_led();
    init_zumbador();
    init_pulsador();

    while (!system_on) {

    }

    mostrarSystemOn();
    while (1) {

        write_LCD(f1, fila_arriba);
        write_LCD(f2, fila_abajo);
    }

#if BSP_TZ_SECURE_BUILD
    /* Enter non-secure code */
    R_BSP_NonSecureEnter();
#endif
}



fsp_err_t icu_init(void)
{
    fsp_err_t err = FSP_SUCCESS;

    /* Open ICU module */
    err = R_ICU_ExternalIrqOpen(&g_external_irq0_ctrl, &g_external_irq0_cfg);
    /* Handle error */
    if (FSP_SUCCESS != err)
    {
        /* ICU Open failure message */
        //APP_ERR_PRINT ("\r\n*R_ICU_ExternalIrqOpen API FAILED*\r\n");
    }
    return err;
}

fsp_err_t icu_enable(void)
{
    fsp_err_t err = FSP_SUCCESS;

    /* Enable ICU module */
    err = R_ICU_ExternalIrqEnable(&g_external_irq0_ctrl);

    /* Handle error */
    if (FSP_SUCCESS != err)
    {
        /* ICU Enable failure message */
       // APP_ERR_PRINT ("\r\n*R_ICU_ExternalIrqEnable API FAILED*\r\n");
    }
    return err;
}

void icu_deinit(void)
{
    fsp_err_t err = FSP_SUCCESS;

    /* Close ICU module */
    err = R_ICU_ExternalIrqClose(&g_external_irq0_ctrl);
    /* Handle error */
    if (FSP_SUCCESS != err)
    {
        /* ICU Close failure message */
        //APP_ERR_PRINT("\r\n*R_ICU_ExternalIrqClose API FAILED*\r\n");
    }
}
// función para comprobar el bit de paridad PAR


/******************************************************************************************************************//*
 * This function is called at various points during the startup process.  This implementation uses the event that is
 * called right before main() to set up the pins.
 *
 * @param[in]  event    Where at in the start up process the code is currently at
 **********************************************************************************************************************/
void R_BSP_WarmStart(bsp_warm_start_event_t event)
{
    if (BSP_WARM_START_RESET == event)
    {
#if BSP_FEATURE_FLASH_LP_VERSION != 0

        /* Enable reading from data flash. */
        R_FACI_LP->DFLCTL = 1U;

        /* Would normally have to wait tDSTOP(6us) for data flash recovery. Placing the enable here, before clock and
         * C runtime initialization, should negate the need for a delay since the initialization will typically take more than 6us. */
#endif
    }

    if (BSP_WARM_START_POST_C == event)
    {
        /* C runtime environment and system clocks are setup. */

        /* Configure pins. */
        R_IOPORT_Open (&g_ioport_ctrl, g_ioport.p_cfg);
    }
}

#if BSP_TZ_SECURE_BUILD

BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ();

/* Trustzone Secure Projects require at least one nonsecure callable function in order to build (Remove this if it is not required to build). */
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ()
{

}
#endif
