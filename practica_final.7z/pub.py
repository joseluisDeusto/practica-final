import paho.mqtt.publish as publish
import json
import random
import time
from datetime import datetime

def enviar_mensaje_mqtt(hostname, timestamp, valor_pot):
    #1. definir el topic
    topic = "pot"
    mensaje = {
        "timestamp": timestamp,
        "value": valor_pot,
    }

    mensaje_json= json.dumps(mensaje)
    publish.single(topic=topic, payload=mensaje_json, qos=1, hostname=hostname, keepalive=60)
    print("Pubicacion hecha, se ha enviado el valor potenciometro", valor_pot)




while True:
    aleatorio = random.randrange(100, 17000) # valor aleatorio entre 100 y 500
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S") # Formato de fecha y hora
    f = open("log.txt", "a")
    f = open("log.txt", "a")
    f.write("Fecha y hora: " + str(timestamp) + "    Potenciometro: " + str(aleatorio) + "\n")
    enviar_mensaje_mqtt("Deusto-2020-029", timestamp, aleatorio)
    time.sleep(5)
    f.close()

    